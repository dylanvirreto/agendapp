// app/(tabs)/_layout.tsx
import React from 'react';
import { Tabs } from 'expo-router';
import { Text, View } from 'react-native';
import { useApp } from '../../src/context/AppContext';

function TabIcon({ emoji, label, focused }: { emoji: string; label: string; focused: boolean }) {
  const { C } = useApp();
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', paddingTop: 6 }}>
      <Text style={{ fontSize: 20, opacity: focused ? 1 : 0.55 }}>{emoji}</Text>
      <Text style={{
        fontSize: 10, fontWeight: focused ? '700' : '500',
        color: focused ? C.wine : C.textMuted,
        marginTop: 2, letterSpacing: 0.3,
      }}>
        {label}
      </Text>
      {focused && (
        <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: C.wine, marginTop: 2 }} />
      )}
    </View>
  );
}

export default function TabsLayout() {
  const { C } = useApp();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: C.navBg,
          borderTopColor: C.border,
          borderTopWidth: 1,
          height: 68,
          paddingBottom: 0,
          elevation: 8,
          shadowColor: C.wine,
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.06,
          shadowRadius: 8,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon emoji="⌂" label="Inicio" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="calendar"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon emoji="📅" label="Calendario" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="tasks"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon emoji="☑" label="Tareas" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="notes"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon emoji="📝" label="Notas" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          tabBarIcon: ({ focused }) => (
            <TabIcon emoji="⚙" label="Ajustes" focused={focused} />
          ),
        }}
      />
    </Tabs>
  );
}
